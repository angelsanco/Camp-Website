var mongoose = require("mongoose");

//DB Schema
var campSchema = new mongoose.Schema({
    name: String,
    price: String,
    image: String,
    description: String,
    author: { // we can name this anything but just to be consistent we named it author which is also present in commentSchema
        id: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User"
        },
        username: String
    },
    comments: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "Comment"
    }
    ]

});


// var Camp = mongoose.model("Camp", campSchema);
module.exports = mongoose.model("Camp", campSchema);