var mongoose = require("mongoose");
var Camp = require("./models/camp");
var Comment = require("./models/comment")

var data = [
    {
        name: "san",
        image: "https://pixabay.com/get/g42902718628cd6f0cc9fc189de8b5aa9f10cd2b4eeca08e94394c960c5d2781b0e3f23354f59781f9c1694535009acec_340.jpg",
        description: "ssssss"
    },
    {
        name: "angel",
        image: "https://pixabay.com/get/gc3af6271b701f0de08d671a7f06f8bf4275c9bec4d1dee1a1ecb9da9876d258e104a0cab9ce39e0050d84c0d49becd75_340.jpg",
        description:"aaaaaa"
    },  
    {
        name: "dan",
        image: "https://pixabay.com/get/g62394ca2b8edd935aa46a30376f4e3b55484f1a759dcba841bb2a1ba9c01d3823328fcebacd71b22374eaa7f8d951e4f_340.jpg",
        description:"ddddd"
    },
    {
        name: "san",
        image: "https://pixabay.com/get/g42902718628cd6f0cc9fc189de8b5aa9f10cd2b4eeca08e94394c960c5d2781b0e3f23354f59781f9c1694535009acec_340.jpg",
        description: "ssssss"
    },
    {
        name: "angel",
        image: "https://pixabay.com/get/gc3af6271b701f0de08d671a7f06f8bf4275c9bec4d1dee1a1ecb9da9876d258e104a0cab9ce39e0050d84c0d49becd75_340.jpg",
        description:"aaaaaa"
    },  
    {
        name: "dan",
        image: "https://pixabay.com/get/g62394ca2b8edd935aa46a30376f4e3b55484f1a759dcba841bb2a1ba9c01d3823328fcebacd71b22374eaa7f8d951e4f_340.jpg",
        description:"ddddd"
    },
    {
        name: "san",
        image: "https://pixabay.com/get/g42902718628cd6f0cc9fc189de8b5aa9f10cd2b4eeca08e94394c960c5d2781b0e3f23354f59781f9c1694535009acec_340.jpg",
        description: "ssssss"
    },
    {
        name: "angel",
        image: "https://pixabay.com/get/gc3af6271b701f0de08d671a7f06f8bf4275c9bec4d1dee1a1ecb9da9876d258e104a0cab9ce39e0050d84c0d49becd75_340.jpg",
        description:"aaaaaa"
    },  
    {
        name: "dan",
        image: "https://pixabay.com/get/g62394ca2b8edd935aa46a30376f4e3b55484f1a759dcba841bb2a1ba9c01d3823328fcebacd71b22374eaa7f8d951e4f_340.jpg",
        description:"ddddd"
    },
    {
        name: "san",
        image: "https://pixabay.com/get/g42902718628cd6f0cc9fc189de8b5aa9f10cd2b4eeca08e94394c960c5d2781b0e3f23354f59781f9c1694535009acec_340.jpg",
        description: "ssssss"
    },
    {
        name: "angel",
        image: "https://pixabay.com/get/gc3af6271b701f0de08d671a7f06f8bf4275c9bec4d1dee1a1ecb9da9876d258e104a0cab9ce39e0050d84c0d49becd75_340.jpg",
        description:"aaaaaa"
    },  
    {
        name: "dan",
        image: "https://pixabay.com/get/g62394ca2b8edd935aa46a30376f4e3b55484f1a759dcba841bb2a1ba9c01d3823328fcebacd71b22374eaa7f8d951e4f_340.jpg",
        description:"ddddd"
    }
];


function seedDB(){

    // remove all campgrounds
    Camp.remove({}, function(err, f){
        // if (err) {
        //     console.log(err);
        // }  
        // console.log("removed");

        //  //add a few campgrounds
        // data.forEach(function(seed){
        //     Camp.create(seed, function(err, done){
        //         if (err) {
        //             console.log(err);
        //         } else {
        //             console.log("Added");
        //             //create a comment
        //             Comment.create(
        //                 {
        //                 text: "Nice site",
        //                 author: "ssd"
        //                }, function(err, s){
        //                 if (err) {
        //                     console.log(err);
        //                 } else {
        //                     done.comments.push(s);
        //                     done.save();
        //                     console.log("new comment");
        //                 }
        //             })
        //         }
        //     });
        // }); 

    });

   
  

    //add a few comments
}


module.exports = seedDB;

