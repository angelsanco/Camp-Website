var express = require("express");
var router = express.Router({mergeParams: true});
var Camp = require("../models/camp");
var middleware = require("../middleware"); //the index file runs by default

//INDEX
router.get("/", function(req, res){
    Camp.find({}, function(err, ifnot){
        if (err) {
            console.log("There's an error");
            console.log(err);
        } else {
            res.render("campgrounds/index", {campgrounds: ifnot});
        }
    });
    
});

//CREATE
router.post("/", middleware.isLoggedIn,  function(req, res){
    //get data from the form (in new.ejs) and add to campgrounds array
    var n = req.body.nameeee;
    var i = req.body.imageeee;
    var j = req.body.descp;
   var m = req.body.price;
    var author = {
        id: req.user._id,
        username: req.user.username
    }; 
    var k = {name: n, image:i, description: j, author: author, price: m};
    // console.log(req.user);

    //create new camp and save to DB
    Camp.create(k, function(err,show){
        if (err) {
            console.log(err);
        } else {
            // console.log(show);
            res.redirect("/campgrounds"); // redirect is by default set to the get route.
        }
    })
    // res.redirect("/campgrounds"); // redirect is by default set to the get route.
});

//NEW
router.get("/new", middleware.isLoggedIn,  function(req, res){
    res.render("campgrounds/new");
});

//SHOW
router.get("/:id", function(req, res) {
    Camp.findById(req.params.id).populate("comments").exec(function(err, found){
        if (err) {
            console.log(err);
        } else {
            res.render("campgrounds/show", {campGround: found});
        }
    })
});

//Edit
router.get("/:id/edit", middleware.checkCampAuthorization, function(req, res){
    Camp.findById(req.params.id, function(err, done){
    res.render("campgrounds/edit", {camp: done});
    });
});

//Update
router.put("/:id", middleware.checkCampAuthorization, function(req, res){
    Camp.findByIdAndUpdate(req.params.id, req.body.edit, function(err, done){
        if(err){
            console.log(err);
        } else{
            res.redirect("/campgrounds/" + req.params.id);
        };
    });
});

//delete

router.delete("/:id", middleware.checkCampAuthorization, function(req, res){
    Camp.findByIdAndDelete(req.params.id, function(err, done){
        res.redirect("/campgrounds");
    });
});

module.exports = router;