var express = require("express");
var router = express.Router({mergeParams: true});
var Camp = require("../models/camp");
var Comment = require("../models/comment");
var middleware = require("../middleware"); //the index file runs by default

//COMMENTS ROUTES
router.get("/new", middleware.isLoggedIn, function(req, res){
    //find campground by id
    Camp.findById(req.params.id, function(err, campground){
        if (err) {
            console.log(err);
        } else {
            res.render("comments/new", {campground: campground});
        };
    });
});
//COMMENTS CREATE
router.post("/", middleware.isLoggedIn, function(req, res){
    Camp.findById(req.params.id, function(err, found){
        if (err) {
            console.log(err);
            res.redirect("/campgrounds")
        } else {
            Comment.create(req.body.comments, function(err, done){
                if (err) {
                    req.flash("error", "Something went wrong!!");
                    console.log(err);
                } else {
                    //add username and id to comment
                    done.author.id       = req.user._id;
                    done.author.username = req.user.username;
                    //save
                    done.save();
                    
                    found.comments.push(done); 
                    found.save();
                    req.flash("success", "Successfully added your comment!!");
                    res.redirect("/campgrounds/" + req.params.id); //u can also add found._id
                    // console.log(req.params.id);
                };
            });
        };
    });
});

//edit comment ----> /campgrounds/:id/comments/:comment_id/edit   ///we cannot name both the params :id cuz they'll overlap.
router.get("/:comment_id/edit", middleware.checkCommentAuthorization, function(req, res){
    Camp.findById(req.params.id, function(err, done){
        Comment.findById(req.params.comment_id, function(err, foundComment){
            res.render("comments/edit", {comment: foundComment, campground: done});
        });
    });
});

//update comment
router.put("/:comment_id", middleware.checkCommentAuthorization, function(req, res){
    Comment.findByIdAndUpdate(req.params.comment_id, req.body.comments, function(err, done){
        res.redirect("/campgrounds/"+ req.params.id);
    });
});

//delete comment
router.delete("/:comment_id", middleware.checkCommentAuthorization, function(req, res){
    Comment.findByIdAndRemove(req.params.comment_id, function(err, done){
        req.flash("success", "Comment deleted!!");
        res.redirect("back");
    });
});

module.exports = router;