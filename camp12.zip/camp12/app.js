var express               = require("express"),
    app                   = express(),
    bodyParser            = require("body-parser"),
    mongoose              = require("mongoose"),
    Camp                  = require("./models/camp"),
    Comment               = require("./models/comment"),
    seedDB                = require("./seeds"),
    passport              = require("passport"),
    LocalStrategy         = require("passport-local"),
    passportLocalMongoose = require("passport-local-mongoose"),
    User                  = require("./models/user"),
    methodOverride        = require("method-override"),
    flash                 = require("connect-flash");

    //requiring routes
var  campgroundRoutes = require("./routes/campgrounds"),
     commentRoutes    = require("./routes/comments"),
     indexRoutes      = require("./routes/index");

mongoose.connect("mongodb://localhost/camp_final");
app.use(express.static(__dirname + "/public")); // console.log(__dirname);
app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({extended :true}));
app.use(methodOverride("_method"));
app.use(flash());
// seedDB();

//PASSPORT CONFIGURATION
app.use(require("express-session")({
    secret: "guess",
    resave: false,
    saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

// this is used here to avoid repetation of passing this: currentUser: req.user. do console.log(req.user) to find the user credentials.
//this leads to knowing the current state of user (logged in or not)
app.use(function(req, res, next){
    res.locals.currentUser = req.user;
    res.locals.error = req.flash("error");
    res.locals.success = req.flash("success");
    next();
});

app.use("/campgrounds", campgroundRoutes);
app.use("/campgrounds/:id/comments", commentRoutes);
app.use("/", indexRoutes);

app.listen(5500, function(){
    console.log("Server is listening on port 5500");
});